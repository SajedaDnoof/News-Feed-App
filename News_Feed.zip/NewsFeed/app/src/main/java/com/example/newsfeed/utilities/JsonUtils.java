package com.example.newsfeed.utilities;

import com.example.newsfeed.model.Story;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class JsonUtils {
    private static final String KEY_RESPONSE = "response";
    private static final String KEY_RESULTS = "results";
    private static final String KEY_ID = "id";
    private static final String KEY_TYPE = "type";
    private static final String KEY_DATE = "webPublicationDate";
    private static final String KEY_WEB_TITLE = "webTitle";
    private static final String KEY_URL = "webUrl";
    private static final String KEY_AUTHOR = "author";
    private static final String KEY_SECTION = "sectionName";
    private static final String KEY_TAG = "tags";

    public static List<Story> parseStoriesFromJson(String json) {
        List<Story> stories = new ArrayList<>();
        try {
            JSONObject jsonObject = new JSONObject(json);
            JSONArray jsonResults = jsonObject.getJSONObject(KEY_RESPONSE)
                    .getJSONArray(KEY_RESULTS);
            for (int i = 0; i < jsonResults.length(); i++) {
                JSONObject jo = jsonResults.getJSONObject(i);

                String webPublicationDate = null;
                String webTitle = null;
                String webUrl = null;
                String sectionName = null;
                if (jo.has(KEY_DATE))
                    webPublicationDate = formatDate(jo.getString(KEY_DATE));
                if (jo.has(KEY_WEB_TITLE))
                    webTitle = jo.getString(KEY_WEB_TITLE);
                if (jo.has(KEY_URL))
                    webUrl = jo.getString(KEY_URL);
                if (jo.has(KEY_SECTION))
                    sectionName = jo.getString(KEY_SECTION);
                List<String> authors = new ArrayList<>();
                if (jo.has(KEY_TAG)) {
                    JSONArray jsonArrayTags = jo.getJSONArray(KEY_TAG);
                    for (int k = 0; k < jsonArrayTags.length(); k++) {
                        JSONObject object = jsonArrayTags.getJSONObject(k);
                        String name = object.getString(KEY_WEB_TITLE);
                        authors.add(name);
                    }
                }
                stories.add(new Story(webPublicationDate, webTitle, webUrl, authors, sectionName));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return stories;
    }

    private static String formatDate(String dateString) {
        String pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'";
        SimpleDateFormat dateFormatter = new SimpleDateFormat(pattern, Locale.getDefault());
        try {
            Date parsedDate = dateFormatter.parse(dateString);
            String pattern2 = "d MMM yyyy";
            SimpleDateFormat dateFormatter2 = new SimpleDateFormat(pattern2, Locale.getDefault());
            return dateFormatter2.format(parsedDate);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
