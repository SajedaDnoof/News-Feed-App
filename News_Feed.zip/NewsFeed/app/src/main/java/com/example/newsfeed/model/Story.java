package com.example.newsfeed.model;

import java.util.List;

public class Story {
    private String webPublicationDate;
    private String webTitle;
    private String webUrl;
    private List<String> author;
    private String sectionName;


    public String getWebPublicationDate() {
        return webPublicationDate;
    }

    public String getWebTitle() {
        return webTitle;
    }

    public String getWebUrl() {
        return webUrl;
    }

    public List<String> getAuthor() {
        return author;
    }

    public String getSectionName() {
        return sectionName;
    }
    public Story(String webPublicationDate, String webTitle, String webUrl, List<String> author, String sectionName) {
        this.webPublicationDate = webPublicationDate;
        this.webTitle = webTitle;
        this.webUrl = webUrl;
        this.author = author;
        this.sectionName = sectionName;
    }
}
