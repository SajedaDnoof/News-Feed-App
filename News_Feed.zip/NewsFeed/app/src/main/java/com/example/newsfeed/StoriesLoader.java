package com.example.newsfeed;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.AsyncTaskLoader;

import com.example.newsfeed.model.Story;
import com.example.newsfeed.utilities.JsonUtils;
import com.example.newsfeed.utilities.NetworkUtils;

import java.net.URL;
import java.util.List;

public class StoriesLoader extends AsyncTaskLoader<List<Story>> {
    private URL url;

    public StoriesLoader(@NonNull Context context, URL url) {
        super(context);
        this.url = url;
    }

    @Nullable
    @Override
    public List<Story> loadInBackground() {
        try {
            if (!NetworkUtils.isOnline())
                return null;
            String response = NetworkUtils.getResponseFromHttpUrl(url);
            return JsonUtils.parseStoriesFromJson(response);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
