package com.example.newsfeed;

import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.newsfeed.model.Story;

import java.util.List;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.NewsHolder> {
    private List<Story> stories;

    public void setStories(List<Story> stories) {
        this.stories = stories;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public NewsHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        View view = inflater.inflate(R.layout.story_item, viewGroup, false);
        return new NewsHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NewsHolder newsHolder, int i) {
        newsHolder.bind(i);
    }

    @Override
    public int getItemCount() {
        return stories == null ? 0 : stories.size();
    }

    class NewsHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView titleTv, authorTv, dateTv, sectionNameTv;

        public NewsHolder(@NonNull View itemView) {
            super(itemView);
            dateTv = itemView.findViewById(R.id.date_tv);
            authorTv = itemView.findViewById(R.id.author_tv);
            titleTv = itemView.findViewById(R.id.title_tv);
            sectionNameTv = itemView.findViewById(R.id.section_name_tv);

            itemView.setOnClickListener(this);
        }

        public void bind(int position) {
            Story story = stories.get(position);
            dateTv.setText(story.getWebPublicationDate());
            titleTv.setText(story.getWebTitle());
            sectionNameTv.setText(story.getSectionName());
            if (story.getAuthor() != null && !story.getAuthor().isEmpty()) {
                authorTv.setText(TextUtils.join(",", story.getAuthor()));
                authorTv.setVisibility(View.VISIBLE);
            } else {
                authorTv.setVisibility(View.GONE);
            }
        }

        @Override
        public void onClick(View view) {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(stories.get(getAdapterPosition()).getWebUrl()));
            view.getContext().startActivity(browserIntent);
        }
    }
}
